#!/usr/bin/env python3
"""
MCP Usability Audit Agent CLI Entry Point
"""
from .cli import main

if __name__ == "__main__":
    main() 