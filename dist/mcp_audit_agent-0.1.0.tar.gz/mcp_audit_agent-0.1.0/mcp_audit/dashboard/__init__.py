"""
Web dashboard for real-time MCP audit monitoring.
"""

from .app import create_dashboard_app

__all__ = ["create_dashboard_app"] 